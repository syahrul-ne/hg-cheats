<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta ch  <title>Dashboard - HG CHEATS</title>  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <link rel="stylesheet" href="assets/style.css" />
  <style>
    /* Estilos customizados para melhorar o tema */
    .btn-gradient {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      transition: all 0.3s ease;
    }
    .btn-gradient:hover {
      background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
      transform: translateY(-2px);
      box-shadow: 0 10px 20px rgba(0,0,0,0.2);
    }
    .text-gradient {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }
    .card-hover {
      transition: all 0.3s ease;
    }
    .card-hover:hover {
      transform: translateY(-5px);
      box-shadow: 0 20px 40px rgba(0,0,0,0.1);
    }
    .animate-fadeInUp {
      animation: fadeInUp 0.6s ease-out;
    }
    .animate-slideDown {
      animation: slideDown 0.6s ease-out;
    }
    .animate-fadeInLeft {
      animation: fadeInLeft 0.6s ease-out;
    }
    .stagger-children > * {
      animation-delay: calc(var(--stagger-delay, 0) * 0.1s);
    }
    
    /* Animações para modais */
    .modal-show {
      opacity: 1 !important;
      transform: scale(1) !important;
    }
    
    /* Correção específica para gráficos */
    .chart-container {
      position: relative;
      height: 300px;
      width: 100%;
      display: block;
    }
    
    .chart-container canvas {
      display: block !important;
      width: 100% !important;
      height: 100% !important;
    }
    
    @keyframes fadeInUp {
      from {
        opacity: 0;
        transform: translateY(30px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
    @keyframes slideDown {
      from {
        opacity: 0;
        transform: translateY(-30px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
    @keyframes fadeInLeft {
      from {
        opacity: 0;
        transform: translateX(-30px);
      }
      to {
        opacity: 1;
        transform: translateX(0);
      }
    }
    .delay-200 { animation-delay: 0.2s; }
    .delay-300 { animation-delay: 0.3s; }
    .delay-400 { animation-delay: 0.4s; }
    .delay-500 { animation-delay: 0.5s; }
    .delay-600 { animation-delay: 0.6s; }
    .delay-700 { animation-delay: 0.7s; }
    .delay-800 { animation-delay: 0.8s; }
  </style>
</head>
<body class="bg-[#0f172a] text-white min-h-screen">

<div class="flex min-h-screen">
  
<!-- Botão do menu hambúrguer para mobile -->
<button id="sidebarToggle" class="fixed top-4 left-4 z-50 md:hidden bg-[#1e293b] text-white p-3 rounded-lg shadow-lg border border-slate-700/50 hover:bg-[#334155] transition-all duration-200">
  <i class="fas fa-bars text-lg"></i>
</button>

<!-- Overlay para mobile -->
<div id="sidebarOverlay" class="fixed inset-0 bg-black bg-opacity-50 z-30 hidden md:hidden"></div>

<div id="sidebar" class="bg-[#1e293b] text-white w-64 pt-1 flex-shrink-0 h-screen fixed top-0 left-0 z-40 transition-transform duration-200 ease-in-out md:translate-x-0 -translate-x-full md:flex flex-col animate-fadeInLeft border-r border-slate-700/50 overflow-y-auto">
    
  <!-- Logo -->
  <div class="flex items-center justify-center h-20 px-6 border-b border-slate-600/30">
    <div class="text-2xl font-bold tracking-wider text-white">
      <span class="text-indigo-400">HG</span>
      <span class="text-slate-300 ml-1">CHEATS</span>
    </div>
  </div>

  <!-- Menu -->
  <nav class="sidebar-nav flex flex-col flex-grow px-4 py-6 space-y-1">
   
    <a href="dashboard" class="sidebar-item flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 bg-gradient-to-r from-indigo-600 to-indigo-700 text-white shadow-lg border border-indigo-500/50">
      <i class="fa-solid fa-gauge text-indigo-400"></i>
      <span class="font-medium">Dashboard</span>
    </a>
   
    
    <a href="usuarios" class="sidebar-item flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 hover:bg-[#334155] text-slate-300 hover:text-white">
      <i class="fa-solid fa-users text-blue-400"></i>
      <span class="font-medium">Keys</span>
    </a>
    
    <a href="logins_tempo_real" class="sidebar-item flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 hover:bg-[#334155] text-slate-300 hover:text-white">
      <i class="fa-solid fa-circle-dot text-emerald-400 pulse-dot"></i>
      <span class="font-medium">Logins Online</span>
    </a>
     
    <a href="gerenciar_logins" class="sidebar-item flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 hover:bg-[#334155] text-slate-300 hover:text-white">
      <i class="fa-solid fa-sign-out-alt text-red-400"></i>
      <span class="font-medium">Gerenciar Logins</span>
    </a>
    
       <a href="revendedores" class="sidebar-item flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 hover:bg-[#334155] text-slate-300 hover:text-white">
      <i class="fa-solid fa-user-friends text-pink-400"></i>
      <span class="font-medium">Revendedores</span>
    </a>
        
    <a href="produto" class="sidebar-item flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 hover:bg-[#334155] text-slate-300 hover:text-white">
      <i class="fa-solid fa-tags text-orange-400"></i>
      <span class="font-medium">Produtos</span>
    </a>
    
        <a href="api_config" class="sidebar-item flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 hover:bg-[#334155] text-slate-300 hover:text-white">
      <i class="fa-solid fa-key text-cyan-400"></i>
      <span class="font-medium">API Config</span>
    </a>
    
        
        <a href="creditos" class="sidebar-item flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 hover:bg-[#334155] text-slate-300 hover:text-white">
      <i class="fa-solid fa-coins text-yellow-400"></i>
      <span class="font-medium">Créditos</span>
    </a>
      </nav>
  
  <!-- Informações do Usuário -->
    <div class="sidebar-user-info">
    <div class="user-info-card">
      <div class="user-name">
        <i class="fa-solid fa-user text-slate-400"></i>
        cuban04      </div>
      <div class="user-role seller">
        <i class="fa-solid fa-handshake text-xs"></i>
        Vendedor      </div>
      <!-- Créditos com estilo verde mais bonito e legível -->
      <div class="user-credits bg-gradient-to-r from-emerald-500/25 to-green-500/25 border border-emerald-400/40 rounded-lg p-2.5 mt-2 backdrop-blur-sm shadow-md hover:shadow-lg transition-all duration-300 hover:from-emerald-500/30 hover:to-green-500/30">
        <div class="flex items-center justify-center gap-2">
          <i class="fa-solid fa-coins text-emerald-300 text-base animate-pulse drop-shadow-sm"></i>
          <span class="text-emerald-100 font-bold text-base tracking-wide drop-shadow-sm">R$ 0,00</span>
        </div>
      </div>
      
        <a href="logout" class="sidebar-logout flex items-center justify-center gap-1 px-2 py-1.5 mt-1.5 rounded-md transition-all duration-200 bg-red-500/10 border border-red-500/30 text-red-400 hover:bg-red-500/20 hover:text-red-300 hover:border-red-400/50">
      <i class="fa-solid fa-right-from-bracket text-xs"></i>
      <span class="font-medium text-xs">Sair</span>
    </a>
    </div>
  </div>
  </div>

<script>
// Script para controle do sidebar mobile
document.addEventListener('DOMContentLoaded', function() {
  const sidebarToggle = document.getElementById('sidebarToggle');
  const sidebar = document.getElementById('sidebar');
  const sidebarOverlay = document.getElementById('sidebarOverlay');
  
  // Função para abrir sidebar
  function openSidebar() {
    sidebar.classList.remove('-translate-x-full');
    sidebarOverlay.classList.remove('hidden');
    document.body.style.overflow = 'hidden'; // Prevenir scroll do body
  }
  
  // Função para fechar sidebar
  function closeSidebar() {
    sidebar.classList.add('-translate-x-full');
    sidebarOverlay.classList.add('hidden');
    document.body.style.overflow = ''; // Restaurar scroll do body
  }
  
  // Event listener para o botão hambúrguer
  if (sidebarToggle) {
    sidebarToggle.addEventListener('click', function(e) {
      e.stopPropagation();
      if (sidebar.classList.contains('-translate-x-full')) {
        openSidebar();
      } else {
        closeSidebar();
      }
    });
  }
  
  // Event listener para o overlay
  if (sidebarOverlay) {
    sidebarOverlay.addEventListener('click', closeSidebar);
  }
  
  // Fechar sidebar ao clicar em um link (mobile)
  const sidebarLinks = sidebar.querySelectorAll('.sidebar-item');
  sidebarLinks.forEach(link => {
    link.addEventListener('click', function() {
      // Só fechar em mobile
      if (window.innerWidth < 768) {
        closeSidebar();
      }
    });
  });
  
  // Fechar sidebar ao redimensionar para desktop
  window.addEventListener('resize', function() {
    if (window.innerWidth >= 768) {
      closeSidebar();
    }
  });
  
  // Fechar sidebar com tecla ESC
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && !sidebar.classList.contains('-translate-x-full')) {
      closeSidebar();
    }
  });
});

// Função para voltar ao painel de administrador
function voltarParaAdmin() {
  // Usar o modal de confirmação
  if (typeof window.mostrarConfirmacao === 'function') {
    window.mostrarConfirmacao(
      'Voltar para o Painel de Administrador',
      'Deseja realmente voltar para o painel de administrador?',
      () => {
        // Executar a requisição
        fetch("scripts/voltar_admin.php", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({}),
        })
        .then(response => response.json())
        .then(data => {
          if (data.success) {
            // Usar modal de sucesso com a mensagem "Retornando ao painel de administrador"
            window.mostrarSucesso("Retornando ao painel de administrador");
            setTimeout(() => {
              window.location.href = "dashboard.php";
            }, 1500);
          } else {
            window.mostrarErro(data.message || "Erro ao voltar para o painel de administrador");
          }
        })
        .catch(error => {
          console.error("Erro:", error);
          window.mostrarErro("Erro de conexão");
        });
      }
    );
  } else {
    // Fallback se o modal não estiver disponível
    if (confirm('Deseja realmente voltar para o painel de administrador?')) {
      fetch("scripts/voltar_admin.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({}),
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          alert("Retornando ao painel de administrador");
          window.location.href = "dashboard.php";
        } else {
          alert(data.message || "Erro ao voltar para o painel de administrador");
        }
      })
      .catch(error => {
        console.error("Erro:", error);
        alert("Erro de conexão");
      });
    }
  }
}
</script>


  <div class="flex flex-col flex-1">
    <main class="p-6 flex-1 overflow-y-auto">

      <!-- Título Dashboard no topo -->
      <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 animate-fadeInUp">
        <div>
          <h2 class="text-lg font-semibold flex items-center gap-2">
            <i class="fas fa-tachometer-alt text-blue-400"></i>
            Dashboard
          </h2>
          <p class="text-sm text-slate-400 mt-1">Visão geral do sistema</p>
        </div>
      </div>

      <!-- VALOR TOTAL GERAL - APENAS PARA ADMIN -->
      
      <!-- 1. TOP 1 DO MÊS ANTERIOR (NO TOPO) -->
            <div class="mb-8 animate-fadeInUp delay-300">
        <h3 class="text-lg font-semibold mb-4 flex items-center gap-2">
          <i class="fas fa-crown text-yellow-400"></i>
          👑 Campeão do Mês Anterior
        </h3>
        <div class="bg-[#1e293b] rounded-xl border border-slate-700/50 overflow-hidden">
          <div class="p-4 border-b border-slate-700/50">
            <h4 class="text-md font-medium text-white flex items-center gap-2">
              <i class="fas fa-history text-purple-400"></i>
              October 2025            </h4>
          </div>
          <div class="p-4">
            <div class="flex items-center gap-3 p-4 bg-gradient-to-r from-purple-500/10 to-pink-500/10 rounded-lg border border-purple-500/20">
              <div class="w-12 h-12 flex items-center justify-center rounded-full bg-purple-500/20 text-purple-400 font-bold text-xl">
                <i class="fas fa-crown"></i>
              </div>
              <div class="flex-1 min-w-0">
                <p class="text-white font-bold text-xl">Uriel</p>
                <p class="text-sm text-purple-300">
                  1281 logins • R$ 34.115,00                </p>
              </div>
              <div class="text-purple-400 text-2xl">
                <i class="fas fa-medal"></i>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <!-- 2. TOP 5 DO MÊS ATUAL (NO MEIO) -->
      <div class="mb-8 animate-fadeInUp delay-400">
        <h3 class="text-lg font-semibold mb-4 flex items-center gap-2">
          <i class="fas fa-trophy text-yellow-400"></i>
          🏆 Top 5 Vendas de Logins - November 2025        </h3>
        
        <div class="bg-[#1e293b] rounded-xl border border-slate-700/50 overflow-hidden">
          <div class="p-4 border-b border-slate-700/50">
            <h4 class="text-md font-medium text-white flex items-center gap-2">
              <i class="fas fa-calendar-alt text-blue-400"></i>
              🥇 Ranking Atual
            </h4>
          </div>
          <div class="p-4 space-y-3">
                                          <div class="flex items-center gap-3 p-3 bg-[#0f172a]/50 rounded-lg ">
                  <div class="w-8 h-8 flex items-center justify-center rounded-full bg-yellow-500/20 text-yellow-400 font-bold">
                    1                  </div>
                  <div class="flex-1 min-w-0">
                    <p class="text-white font-medium truncate flex items-center gap-2">
                      JIBONISSEXY                                          </p>
                    <p class="text-xs text-slate-400 truncate">
                      45 logins • R$ 925,00                    </p>
                  </div>
                                      <div class="text-yellow-400">
                      <i class="fas fa-crown"></i>
                    </div>
                                  </div>
                              <div class="flex items-center gap-3 p-3 bg-[#0f172a]/50 rounded-lg ">
                  <div class="w-8 h-8 flex items-center justify-center rounded-full bg-gray-500/20 text-gray-400 font-bold">
                    2                  </div>
                  <div class="flex-1 min-w-0">
                    <p class="text-white font-medium truncate flex items-center gap-2">
                      aimsensi                                          </p>
                    <p class="text-xs text-slate-400 truncate">
                      42 logins • R$ 840,00                    </p>
                  </div>
                                      <div class="text-gray-400">
                      <i class="fas fa-medal"></i>
                    </div>
                                  </div>
                              <div class="flex items-center gap-3 p-3 bg-[#0f172a]/50 rounded-lg ">
                  <div class="w-8 h-8 flex items-center justify-center rounded-full bg-orange-500/20 text-orange-400 font-bold">
                    3                  </div>
                  <div class="flex-1 min-w-0">
                    <p class="text-white font-medium truncate flex items-center gap-2">
                      Sarifgaming                                          </p>
                    <p class="text-xs text-slate-400 truncate">
                      29 logins • R$ 820,00                    </p>
                  </div>
                                      <div class="text-orange-400">
                      <i class="fas fa-award"></i>
                    </div>
                                  </div>
                              <div class="flex items-center gap-3 p-3 bg-[#0f172a]/50 rounded-lg ">
                  <div class="w-8 h-8 flex items-center justify-center rounded-full bg-blue-500/20 text-blue-400 font-bold">
                    4                  </div>
                  <div class="flex-1 min-w-0">
                    <p class="text-white font-medium truncate flex items-center gap-2">
                      BANTIBHAIYA69                                          </p>
                    <p class="text-xs text-slate-400 truncate">
                      21 logins • R$ 525,00                    </p>
                  </div>
                                  </div>
                              <div class="flex items-center gap-3 p-3 bg-[#0f172a]/50 rounded-lg ">
                  <div class="w-8 h-8 flex items-center justify-center rounded-full bg-blue-500/20 text-blue-400 font-bold">
                    5                  </div>
                  <div class="flex-1 min-w-0">
                    <p class="text-white font-medium truncate flex items-center gap-2">
                      XADMINFF                                          </p>
                    <p class="text-xs text-slate-400 truncate">
                      17 logins • R$ 495,00                    </p>
                  </div>
                                  </div>
                                    </div>
        </div>
      </div>

      <!-- 3. GRÁFICOS DE VENDAS -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        
        <!-- Vendas Semanais (Atual) -->
        <div class="animate-fadeInUp delay-500">
          <h3 class="text-lg font-semibold mb-4 flex items-center gap-2">
            <i class="fas fa-chart-line text-green-400"></i>
            📊 Vendas Semanais (Atual)
            <span class="text-xs bg-green-500/20 text-green-300 px-2 py-1 rounded-full ml-2">
              <i class="fas fa-sync-alt animate-spin"></i> Tempo Real
            </span>
          </h3>
          <div class="bg-[#1e293b] rounded-xl border border-slate-700/50 p-4">
            <div class="chart-container">
              <canvas id="weeklySalesCurrentChart"></canvas>
            </div>
          </div>
        </div>

        <!-- Vendas Semanais (Passada) -->
        <div class="animate-fadeInUp delay-600">
          <h3 class="text-lg font-semibold mb-4 flex items-center gap-2">
            <i class="fas fa-chart-bar text-blue-400"></i>
            📈 Vendas Semanais (Passada)
            <span class="text-xs bg-blue-500/20 text-blue-300 px-2 py-1 rounded-full ml-2">
              <i class="fas fa-sync-alt animate-spin"></i> Tempo Real
            </span>
          </h3>
          <div class="bg-[#1e293b] rounded-xl border border-slate-700/50 p-4">
            <div class="chart-container">
              <canvas id="weeklySalesLastChart"></canvas>
            </div>
          </div>
        </div>

        <!-- Vendas Mensais -->
        <div class="animate-fadeInUp delay-700">
          <h3 class="text-lg font-semibold mb-4 flex items-center gap-2">
            <i class="fas fa-chart-area text-purple-400"></i>
            📅 Vendas Mensais
            <span class="text-xs bg-purple-500/20 text-purple-300 px-2 py-1 rounded-full ml-2">
              <i class="fas fa-sync-alt animate-spin"></i> Tempo Real
            </span>
          </h3>
          <div class="bg-[#1e293b] rounded-xl border border-slate-700/50 p-4">
            <div class="chart-container">
              <canvas id="monthlySalesChart"></canvas>
            </div>
          </div>
        </div>

        <!-- Vendas Anuais -->
        <div class="animate-fadeInUp delay-800">
          <h3 class="text-lg font-semibold mb-4 flex items-center gap-2">
            <i class="fas fa-chart-column text-orange-400"></i>
            🗓️ Vendas Anuais
            <span class="text-xs bg-orange-500/20 text-orange-300 px-2 py-1 rounded-full ml-2">
              <i class="fas fa-sync-alt animate-spin"></i> Tempo Real
            </span>
          </h3>
          <div class="bg-[#1e293b] rounded-xl border border-slate-700/50 p-4">
            <div class="chart-container">
              <canvas id="annualSalesChart"></canvas>
            </div>
          </div>
        </div>

      </div>

    </main>
  </div>
</div>

<script src="assets/js/chart.js"></script>
<script>
let charts = {};

document.addEventListener("DOMContentLoaded", function() {

    
    setTimeout(function() {
        initializeCharts();
        
        // Implementar atualização em tempo real a cada 30 segundos
        setInterval(function() {
            updateCharts();
        }, 30000);
    }, 500);
});

function initializeCharts() {

    console.log("Inicializando gráficos...");

    // Buscar dados iniciais
    fetch('dashboard_api.php')
        .then(response => {
            console.log("Resposta recebida do fetch.");
            return response.json();
        })
        .then(data => {
            console.log("Dados convertidos em JSON:", data);

            if (data.success) {
                console.log("Requisição bem-sucedida. Criando gráficos...");

                // Criar gráficos
                createChart('weeklySalesCurrentChart', 'bar', data.weeklySalesCurrent, 'Vendas Semanais (Atual)', 'rgba(75, 192, 192, 0.6)', 'rgba(75, 192, 192, 1)');
                createChart('weeklySalesLastChart', 'bar', data.weeklySalesLast, 'Vendas Semanais (Passada)', 'rgba(54, 162, 235, 0.6)', 'rgba(54, 162, 235, 1)');
                createChart('monthlySalesChart', 'line', data.monthlySales, 'Vendas Mensais', 'rgba(153, 102, 255, 0.6)', 'rgba(153, 102, 255, 1)');
                createChart('annualSalesChart', 'bar', data.annualSales, 'Vendas Anuais', 'rgba(255, 159, 64, 0.6)', 'rgba(255, 159, 64, 1)');
            } else {
                console.warn("API retornou sucesso = false:", data);
            }
        })
        .catch(error => {
            console.error("Erro ao buscar dados da API:", error);
        });
}


function createChart(canvasId, type, chartData, label, backgroundColor, borderColor) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) {

        return;
    }
    
    const ctx = canvas.getContext("2d");
    
    try {
        charts[canvasId] = new Chart(ctx, {
            type: type,
            data: {
                labels: chartData.labels,
                datasets: [{
                    label: label,
                    data: chartData.data,
                    backgroundColor: backgroundColor,
                    borderColor: borderColor,
                    borderWidth: 2,
                    fill: type === 'line' ? false : true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            color: "#cbd5e1",
                            callback: function(value) {
                                return 'R$ ' + value.toFixed(2);
                            }
                        },
                        grid: {
                            color: "rgba(100, 116, 139, 0.3)"
                        }
                    },
                    x: {
                        ticks: {
                            color: "#cbd5e1"
                        },
                        grid: {
                            color: "rgba(100, 116, 139, 0.3)"
                        }
                    }
                },
                plugins: {
                    legend: {
                        labels: {
                            color: "#cbd5e1"
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return context.dataset.label + ': R$ ' + context.parsed.y.toFixed(2);
                            }
                        }
                    }
                }
            }
        });
        
        console.log(`Gráfico ${canvasId} criado com sucesso`);
        
    } catch (error) {
        console.error(`Erro ao criar gráfico ${canvasId}:`, error);
    }
}

// Função para atualizar os gráficos em tempo real
function updateCharts() {
    console.log("Atualizando gráficos em tempo real...");
    
    fetch('dashboard_api.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                console.log("Dados atualizados recebidos:", data);
                
                // Atualizar cada gráfico
                updateChart('weeklySalesCurrentChart', data.weeklySalesCurrent);
                updateChart('weeklySalesLastChart', data.weeklySalesLast);
                updateChart('monthlySalesChart', data.monthlySales);
                updateChart('annualSalesChart', data.annualSales);
                
                // Atualizar valor total para admin
                const isAdmin = false;
                if (isAdmin) {
                    updateTotalValue();
                }

                console.log("Todos os gráficos atualizados com sucesso");
            }
        })
        .catch(error => {
            console.error("Erro ao buscar dados da API:", error);
        });
}


function updateChart(chartId, newData) {
    if (charts[chartId]) {
        charts[chartId].data.labels = newData.labels;
        charts[chartId].data.datasets[0].data = newData.data;
        charts[chartId].update();
    }
}


// Debug: Verificar se Chart.js foi carregado
if (typeof Chart !== 'undefined') {
    console.log("Chart.js carregado com sucesso");
} else {
    console.error("Chart.js não foi carregado");
}
</script>

<script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"version":"2024.11.0","token":"f288f319f18e490b9a89e8a7805b0616","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
</body>
</html>
