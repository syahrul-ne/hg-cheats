<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Produtos - HG CHEATS</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <link rel="stylesheet" href="assets/style.css" />
</head>
<body class="bg-[#0f172a] text-white min-h-screen">

<div class="flex min-h-screen">
  
<!-- Botão do menu hambúrguer para mobile -->
<button id="sidebarToggle" class="fixed top-4 left-4 z-50 md:hidden bg-[#1e293b] text-white p-3 rounded-lg shadow-lg border border-slate-700/50 hover:bg-[#334155] transition-all duration-200">
  <i class="fas fa-bars text-lg"></i>
</button>

<!-- Overlay para mobile -->
<div id="sidebarOverlay" class="fixed inset-0 bg-black bg-opacity-50 z-30 hidden md:hidden"></div>

<div id="sidebar" class="bg-[#1e293b] text-white w-64 pt-1 flex-shrink-0 h-screen fixed top-0 left-0 z-40 transition-transform duration-200 ease-in-out md:translate-x-0 -translate-x-full md:flex flex-col animate-fadeInLeft border-r border-slate-700/50 overflow-y-auto">
    
  <!-- Logo -->
  <div class="flex items-center justify-center h-20 px-6 border-b border-slate-600/30">
    <div class="text-2xl font-bold tracking-wider text-white">
      <span class="text-indigo-400">HG</span>
      <span class="text-slate-300 ml-1">CHEATS</span>
    </div>
  </div>

  <!-- Menu -->
  <nav class="sidebar-nav flex flex-col flex-grow px-4 py-6 space-y-1">
   
    <a href="dashboard" class="sidebar-item flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 hover:bg-[#334155] text-slate-300 hover:text-white">
      <i class="fa-solid fa-gauge text-indigo-400"></i>
      <span class="font-medium">Dashboard</span>
    </a>
   
    
    <a href="usuarios" class="sidebar-item flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 hover:bg-[#334155] text-slate-300 hover:text-white">
      <i class="fa-solid fa-users text-blue-400"></i>
      <span class="font-medium">Keys</span>
    </a>
    
    <a href="logins_tempo_real" class="sidebar-item flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 hover:bg-[#334155] text-slate-300 hover:text-white">
      <i class="fa-solid fa-circle-dot text-emerald-400 pulse-dot"></i>
      <span class="font-medium">Logins Online</span>
    </a>
     
    <a href="gerenciar_logins" class="sidebar-item flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 hover:bg-[#334155] text-slate-300 hover:text-white">
      <i class="fa-solid fa-sign-out-alt text-red-400"></i>
      <span class="font-medium">Gerenciar Logins</span>
    </a>
    
       <a href="revendedores" class="sidebar-item flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 hover:bg-[#334155] text-slate-300 hover:text-white">
      <i class="fa-solid fa-user-friends text-pink-400"></i>
      <span class="font-medium">Revendedores</span>
    </a>
        
    <a href="produto" class="sidebar-item flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 bg-gradient-to-r from-orange-600 to-orange-700 text-white shadow-lg border border-orange-500/50">
      <i class="fa-solid fa-tags text-orange-400"></i>
      <span class="font-medium">Produtos</span>
    </a>
    
        <a href="api_config" class="sidebar-item flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 hover:bg-[#334155] text-slate-300 hover:text-white">
      <i class="fa-solid fa-key text-cyan-400"></i>
      <span class="font-medium">API Config</span>
    </a>
    
        
        <a href="creditos" class="sidebar-item flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 hover:bg-[#334155] text-slate-300 hover:text-white">
      <i class="fa-solid fa-coins text-yellow-400"></i>
      <span class="font-medium">Créditos</span>
    </a>
      </nav>
  
  <!-- Informações do Usuário -->
    <div class="sidebar-user-info">
    <div class="user-info-card">
      <div class="user-name">
        <i class="fa-solid fa-user text-slate-400"></i>
        cuban04      </div>
      <div class="user-role seller">
        <i class="fa-solid fa-handshake text-xs"></i>
        Vendedor      </div>
      <!-- Créditos com estilo verde mais bonito e legível -->
      <div class="user-credits bg-gradient-to-r from-emerald-500/25 to-green-500/25 border border-emerald-400/40 rounded-lg p-2.5 mt-2 backdrop-blur-sm shadow-md hover:shadow-lg transition-all duration-300 hover:from-emerald-500/30 hover:to-green-500/30">
        <div class="flex items-center justify-center gap-2">
          <i class="fa-solid fa-coins text-emerald-300 text-base animate-pulse drop-shadow-sm"></i>
          <span class="text-emerald-100 font-bold text-base tracking-wide drop-shadow-sm">R$ 0,00</span>
        </div>
      </div>
      
        <a href="logout" class="sidebar-logout flex items-center justify-center gap-1 px-2 py-1.5 mt-1.5 rounded-md transition-all duration-200 bg-red-500/10 border border-red-500/30 text-red-400 hover:bg-red-500/20 hover:text-red-300 hover:border-red-400/50">
      <i class="fa-solid fa-right-from-bracket text-xs"></i>
      <span class="font-medium text-xs">Sair</span>
    </a>
    </div>
  </div>
  </div>

<script>
// Script para controle do sidebar mobile
document.addEventListener('DOMContentLoaded', function() {
  const sidebarToggle = document.getElementById('sidebarToggle');
  const sidebar = document.getElementById('sidebar');
  const sidebarOverlay = document.getElementById('sidebarOverlay');
  
  // Função para abrir sidebar
  function openSidebar() {
    sidebar.classList.remove('-translate-x-full');
    sidebarOverlay.classList.remove('hidden');
    document.body.style.overflow = 'hidden'; // Prevenir scroll do body
  }
  
  // Função para fechar sidebar
  function closeSidebar() {
    sidebar.classList.add('-translate-x-full');
    sidebarOverlay.classList.add('hidden');
    document.body.style.overflow = ''; // Restaurar scroll do body
  }
  
  // Event listener para o botão hambúrguer
  if (sidebarToggle) {
    sidebarToggle.addEventListener('click', function(e) {
      e.stopPropagation();
      if (sidebar.classList.contains('-translate-x-full')) {
        openSidebar();
      } else {
        closeSidebar();
      }
    });
  }
  
  // Event listener para o overlay
  if (sidebarOverlay) {
    sidebarOverlay.addEventListener('click', closeSidebar);
  }
  
  // Fechar sidebar ao clicar em um link (mobile)
  const sidebarLinks = sidebar.querySelectorAll('.sidebar-item');
  sidebarLinks.forEach(link => {
    link.addEventListener('click', function() {
      // Só fechar em mobile
      if (window.innerWidth < 768) {
        closeSidebar();
      }
    });
  });
  
  // Fechar sidebar ao redimensionar para desktop
  window.addEventListener('resize', function() {
    if (window.innerWidth >= 768) {
      closeSidebar();
    }
  });
  
  // Fechar sidebar com tecla ESC
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && !sidebar.classList.contains('-translate-x-full')) {
      closeSidebar();
    }
  });
});

// Função para voltar ao painel de administrador
function voltarParaAdmin() {
  // Usar o modal de confirmação
  if (typeof window.mostrarConfirmacao === 'function') {
    window.mostrarConfirmacao(
      'Voltar para o Painel de Administrador',
      'Deseja realmente voltar para o painel de administrador?',
      () => {
        // Executar a requisição
        fetch("scripts/voltar_admin.php", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({}),
        })
        .then(response => response.json())
        .then(data => {
          if (data.success) {
            // Usar modal de sucesso com a mensagem "Retornando ao painel de administrador"
            window.mostrarSucesso("Retornando ao painel de administrador");
            setTimeout(() => {
              window.location.href = "dashboard.php";
            }, 1500);
          } else {
            window.mostrarErro(data.message || "Erro ao voltar para o painel de administrador");
          }
        })
        .catch(error => {
          console.error("Erro:", error);
          window.mostrarErro("Erro de conexão");
        });
      }
    );
  } else {
    // Fallback se o modal não estiver disponível
    if (confirm('Deseja realmente voltar para o painel de administrador?')) {
      fetch("scripts/voltar_admin.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({}),
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          alert("Retornando ao painel de administrador");
          window.location.href = "dashboard.php";
        } else {
          alert(data.message || "Erro ao voltar para o painel de administrador");
        }
      })
      .catch(error => {
        console.error("Erro:", error);
        alert("Erro de conexão");
      });
    }
  }
}
</script>


  <div class="flex flex-col flex-1">



    <main class="p-6 flex-1 overflow-y-auto">

      <!-- Título Lista de Produtos no topo -->
      <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4 animate-fadeInUp">
        <div>
          <h2 class="text-lg font-semibold flex items-center gap-2">
            <i class="fas fa-list text-purple-400"></i>
            Lista de Produtos
          </h2>
          <p class="text-sm text-slate-400 mt-1">Visualize todos os produtos disponíveis e seus preços</p>
        </div>
      </div>

      <!-- Estatística apenas do total de produtos -->
      <div class="grid grid-cols-1 md:grid-cols-1 gap-4 mb-6 stagger-children">
                
        <div class="bg-[#1e293b] p-4 rounded-xl border border-slate-700/50 card-hover">
          <div class="flex items-center gap-3">
            <div class="bg-purple-500/20 p-3 rounded-full">
              <i class="fas fa-box text-purple-400 text-xl"></i>
            </div>
            <div>
              <p class="text-sm text-slate-400">Total de Produtos</p>
              <p class="text-xl font-bold text-purple-400">1</p>
            </div>
          </div>
        </div>
      </div>

      <div class="overflow-x-auto">
        <table class="min-w-full bg-[#1e293b] rounded-lg overflow-hidden border border-slate-700/50">
          <thead class="bg-[#334155] text-white text-sm">
            <tr>
              <th class="px-6 py-4 text-left font-semibold">Produto</th>
              <th class="px-6 py-4 text-left font-semibold">Opções Disponíveis</th>
              <th class="px-6 py-4 text-left font-semibold">Criado em</th>
            </tr>
          </thead>
          <tbody class="text-gray-300">
                          <tr class="hover:bg-[#0f172a] transition-colors border-b border-slate-700/30">
                <td class="px-6 py-4">
                  <div class="flex flex-col">
                    <span class="font-semibold text-white text-xl">ApkMod Brutal 1.0</span>
                    <span class="text-sm text-slate-400 mt-1">
                      <i class="fas fa-layer-group text-purple-400 mr-1"></i>
                      4 opção(ões) disponível(is)
                    </span>
                  </div>
                </td>
                <td class="px-6 py-4">
                  <div class="flex flex-wrap gap-3">
                                          <div class="bg-[#0f172a] p-3 rounded-lg border border-slate-600/50 min-w-[200px]">
                        <div class="flex items-center justify-between mb-2">
                          <div class="bg-green-500/20 px-2 py-1 rounded border border-green-500/30">
                            <span class="text-green-400 font-bold text-sm">
                              <i class="fas fa-dollar-sign mr-1"></i>
                              R$ 15,00                            </span>
                          </div>
                          <div class="bg-blue-500/20 px-2 py-1 rounded border border-blue-500/30">
                            <span class="text-blue-400 font-bold text-sm">
                              <i class="fas fa-calendar-days mr-1"></i>
                              1 dias
                            </span>
                          </div>
                        </div>
                        <div class="text-xs text-slate-400">
                          <i class="fas fa-info-circle mr-1"></i>
                          ID: 12                        </div>
                      </div>
                                          <div class="bg-[#0f172a] p-3 rounded-lg border border-slate-600/50 min-w-[200px]">
                        <div class="flex items-center justify-between mb-2">
                          <div class="bg-green-500/20 px-2 py-1 rounded border border-green-500/30">
                            <span class="text-green-400 font-bold text-sm">
                              <i class="fas fa-dollar-sign mr-1"></i>
                              R$ 25,00                            </span>
                          </div>
                          <div class="bg-blue-500/20 px-2 py-1 rounded border border-blue-500/30">
                            <span class="text-blue-400 font-bold text-sm">
                              <i class="fas fa-calendar-days mr-1"></i>
                              10 dias
                            </span>
                          </div>
                        </div>
                        <div class="text-xs text-slate-400">
                          <i class="fas fa-info-circle mr-1"></i>
                          ID: 11                        </div>
                      </div>
                                          <div class="bg-[#0f172a] p-3 rounded-lg border border-slate-600/50 min-w-[200px]">
                        <div class="flex items-center justify-between mb-2">
                          <div class="bg-green-500/20 px-2 py-1 rounded border border-green-500/30">
                            <span class="text-green-400 font-bold text-sm">
                              <i class="fas fa-dollar-sign mr-1"></i>
                              R$ 50,00                            </span>
                          </div>
                          <div class="bg-blue-500/20 px-2 py-1 rounded border border-blue-500/30">
                            <span class="text-blue-400 font-bold text-sm">
                              <i class="fas fa-calendar-days mr-1"></i>
                              20 dias
                            </span>
                          </div>
                        </div>
                        <div class="text-xs text-slate-400">
                          <i class="fas fa-info-circle mr-1"></i>
                          ID: 13                        </div>
                      </div>
                                          <div class="bg-[#0f172a] p-3 rounded-lg border border-slate-600/50 min-w-[200px]">
                        <div class="flex items-center justify-between mb-2">
                          <div class="bg-green-500/20 px-2 py-1 rounded border border-green-500/30">
                            <span class="text-green-400 font-bold text-sm">
                              <i class="fas fa-dollar-sign mr-1"></i>
                              R$ 70,00                            </span>
                          </div>
                          <div class="bg-blue-500/20 px-2 py-1 rounded border border-blue-500/30">
                            <span class="text-blue-400 font-bold text-sm">
                              <i class="fas fa-calendar-days mr-1"></i>
                              31 dias
                            </span>
                          </div>
                        </div>
                        <div class="text-xs text-slate-400">
                          <i class="fas fa-info-circle mr-1"></i>
                          ID: 15                        </div>
                      </div>
                                      </div>
                </td>
                <td class="px-6 py-4">
                  <div class="text-slate-300">
                    <i class="fas fa-clock text-slate-400 mr-2"></i>
                    08/08/2025                    <br>
                    <span class="text-sm text-slate-500">14:33</span>
                  </div>
                </td>
              </tr>
                      </tbody>
        </table>
      </div>
    </main>
  </div>
</div>

<script>
function openModal(id) {
  document.getElementById(id).classList.remove("hidden");
}
function closeModal(id) {
  document.getElementById(id).classList.add("hidden");
}
</script>

<script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"version":"2024.11.0","token":"f288f319f18e490b9a89e8a7805b0616","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
</body>
</html>

