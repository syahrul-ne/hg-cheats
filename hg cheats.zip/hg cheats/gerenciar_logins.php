<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Gerenciar Logins Expirados - BR MODS</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <link rel="stylesheet" href="assets/style.css" />
  <script src="modal_functions.js"></script>
  <style>
    /* Estilos customizados para melhorar o tema */
    .btn-gradient {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      transition: all 0.3s ease;
    }
    .btn-gradient:hover {
      background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
      transform: translateY(-2px);
      box-shadow: 0 10px 20px rgba(0,0,0,0.2);
    }
    .text-gradient {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }
    .card-hover {
      transition: all 0.3s ease;
    }
    .card-hover:hover {
      transform: translateY(-5px);
      box-shadow: 0 20px 40px rgba(0,0,0,0.1);
    }
    .animate-fadeInUp {
      animation: fadeInUp 0.6s ease-out;
    }
    .animate-slideDown {
      animation: slideDown 0.6s ease-out;
    }
    .animate-fadeInLeft {
      animation: fadeInLeft 0.6s ease-out;
    }
    .stagger-children > * {
      animation-delay: calc(var(--stagger-delay, 0) * 0.1s);
    }
    
    /* Animações para modais */
    .modal-show {
      opacity: 1 !important;
      transform: scale(1) !important;
    }
    
    @keyframes fadeInUp {
      from {
        opacity: 0;
        transform: translateY(30px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
    @keyframes slideDown {
      from {
        opacity: 0;
        transform: translateY(-30px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
    @keyframes fadeInLeft {
      from {
        opacity: 0;
        transform: translateX(-30px);
      }
      to {
        opacity: 1;
        transform: translateX(0);
      }
    }
    .delay-200 { animation-delay: 0.2s; }
    .delay-300 { animation-delay: 0.3s; }
    .delay-400 { animation-delay: 0.4s; }
  </style>
</head>
<body class="bg-[#0f172a] text-white min-h-screen">

<div class="flex min-h-screen">
  
<!-- Botão do menu hambúrguer para mobile -->
<button id="sidebarToggle" class="fixed top-4 left-4 z-50 md:hidden bg-[#1e293b] text-white p-3 rounded-lg shadow-lg border border-slate-700/50 hover:bg-[#334155] transition-all duration-200">
  <i class="fas fa-bars text-lg"></i>
</button>

<!-- Overlay para mobile -->
<div id="sidebarOverlay" class="fixed inset-0 bg-black bg-opacity-50 z-30 hidden md:hidden"></div>

<div id="sidebar" class="bg-[#1e293b] text-white w-64 pt-1 flex-shrink-0 h-screen fixed top-0 left-0 z-40 transition-transform duration-200 ease-in-out md:translate-x-0 -translate-x-full md:flex flex-col animate-fadeInLeft border-r border-slate-700/50 overflow-y-auto">
    
  <!-- Logo -->
  <div class="flex items-center justify-center h-20 px-6 border-b border-slate-600/30">
    <div class="text-2xl font-bold tracking-wider text-white">
      <span class="text-indigo-400">HG</span>
      <span class="text-slate-300 ml-1">CHEATS</span>
    </div>
  </div>

  <!-- Menu -->
  <nav class="sidebar-nav flex flex-col flex-grow px-4 py-6 space-y-1">
   
    <a href="dashboard" class="sidebar-item flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 hover:bg-[#334155] text-slate-300 hover:text-white">
      <i class="fa-solid fa-gauge text-indigo-400"></i>
      <span class="font-medium">Dashboard</span>
    </a>
   
    
    <a href="usuarios" class="sidebar-item flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 hover:bg-[#334155] text-slate-300 hover:text-white">
      <i class="fa-solid fa-users text-blue-400"></i>
      <span class="font-medium">Keys</span>
    </a>
    
    <a href="logins_tempo_real" class="sidebar-item flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 hover:bg-[#334155] text-slate-300 hover:text-white">
      <i class="fa-solid fa-circle-dot text-emerald-400 pulse-dot"></i>
      <span class="font-medium">Logins Online</span>
    </a>
     
    <a href="gerenciar_logins" class="sidebar-item flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 bg-gradient-to-r from-red-600 to-red-700 text-white shadow-lg border border-red-500/50">
      <i class="fa-solid fa-sign-out-alt text-red-400"></i>
      <span class="font-medium">Gerenciar Logins</span>
    </a>
    
       <a href="revendedores" class="sidebar-item flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 hover:bg-[#334155] text-slate-300 hover:text-white">
      <i class="fa-solid fa-user-friends text-pink-400"></i>
      <span class="font-medium">Revendedores</span>
    </a>
        
    <a href="produto" class="sidebar-item flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 hover:bg-[#334155] text-slate-300 hover:text-white">
      <i class="fa-solid fa-tags text-orange-400"></i>
      <span class="font-medium">Produtos</span>
    </a>
    
        <a href="api_config" class="sidebar-item flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 hover:bg-[#334155] text-slate-300 hover:text-white">
      <i class="fa-solid fa-key text-cyan-400"></i>
      <span class="font-medium">API Config</span>
    </a>
    
        
        <a href="creditos" class="sidebar-item flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 hover:bg-[#334155] text-slate-300 hover:text-white">
      <i class="fa-solid fa-coins text-yellow-400"></i>
      <span class="font-medium">Créditos</span>
    </a>
      </nav>
  
  <!-- Informações do Usuário -->
    <div class="sidebar-user-info">
    <div class="user-info-card">
      <div class="user-name">
        <i class="fa-solid fa-user text-slate-400"></i>
        cuban04      </div>
      <div class="user-role seller">
        <i class="fa-solid fa-handshake text-xs"></i>
        Vendedor      </div>
      <!-- Créditos com estilo verde mais bonito e legível -->
      <div class="user-credits bg-gradient-to-r from-emerald-500/25 to-green-500/25 border border-emerald-400/40 rounded-lg p-2.5 mt-2 backdrop-blur-sm shadow-md hover:shadow-lg transition-all duration-300 hover:from-emerald-500/30 hover:to-green-500/30">
        <div class="flex items-center justify-center gap-2">
          <i class="fa-solid fa-coins text-emerald-300 text-base animate-pulse drop-shadow-sm"></i>
          <span class="text-emerald-100 font-bold text-base tracking-wide drop-shadow-sm">R$ 0,00</span>
        </div>
      </div>
      
        <a href="logout" class="sidebar-logout flex items-center justify-center gap-1 px-2 py-1.5 mt-1.5 rounded-md transition-all duration-200 bg-red-500/10 border border-red-500/30 text-red-400 hover:bg-red-500/20 hover:text-red-300 hover:border-red-400/50">
      <i class="fa-solid fa-right-from-bracket text-xs"></i>
      <span class="font-medium text-xs">Sair</span>
    </a>
    </div>
  </div>
  </div>

<script>
// Script para controle do sidebar mobile
document.addEventListener('DOMContentLoaded', function() {
  const sidebarToggle = document.getElementById('sidebarToggle');
  const sidebar = document.getElementById('sidebar');
  const sidebarOverlay = document.getElementById('sidebarOverlay');
  
  // Função para abrir sidebar
  function openSidebar() {
    sidebar.classList.remove('-translate-x-full');
    sidebarOverlay.classList.remove('hidden');
    document.body.style.overflow = 'hidden'; // Prevenir scroll do body
  }
  
  // Função para fechar sidebar
  function closeSidebar() {
    sidebar.classList.add('-translate-x-full');
    sidebarOverlay.classList.add('hidden');
    document.body.style.overflow = ''; // Restaurar scroll do body
  }
  
  // Event listener para o botão hambúrguer
  if (sidebarToggle) {
    sidebarToggle.addEventListener('click', function(e) {
      e.stopPropagation();
      if (sidebar.classList.contains('-translate-x-full')) {
        openSidebar();
      } else {
        closeSidebar();
      }
    });
  }
  
  // Event listener para o overlay
  if (sidebarOverlay) {
    sidebarOverlay.addEventListener('click', closeSidebar);
  }
  
  // Fechar sidebar ao clicar em um link (mobile)
  const sidebarLinks = sidebar.querySelectorAll('.sidebar-item');
  sidebarLinks.forEach(link => {
    link.addEventListener('click', function() {
      // Só fechar em mobile
      if (window.innerWidth < 768) {
        closeSidebar();
      }
    });
  });
  
  // Fechar sidebar ao redimensionar para desktop
  window.addEventListener('resize', function() {
    if (window.innerWidth >= 768) {
      closeSidebar();
    }
  });
  
  // Fechar sidebar com tecla ESC
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && !sidebar.classList.contains('-translate-x-full')) {
      closeSidebar();
    }
  });
});

// Função para voltar ao painel de administrador
function voltarParaAdmin() {
  // Usar o modal de confirmação
  if (typeof window.mostrarConfirmacao === 'function') {
    window.mostrarConfirmacao(
      'Voltar para o Painel de Administrador',
      'Deseja realmente voltar para o painel de administrador?',
      () => {
        // Executar a requisição
        fetch("scripts/voltar_admin.php", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({}),
        })
        .then(response => response.json())
        .then(data => {
          if (data.success) {
            // Usar modal de sucesso com a mensagem "Retornando ao painel de administrador"
            window.mostrarSucesso("Retornando ao painel de administrador");
            setTimeout(() => {
              window.location.href = "dashboard.php";
            }, 1500);
          } else {
            window.mostrarErro(data.message || "Erro ao voltar para o painel de administrador");
          }
        })
        .catch(error => {
          console.error("Erro:", error);
          window.mostrarErro("Erro de conexão");
        });
      }
    );
  } else {
    // Fallback se o modal não estiver disponível
    if (confirm('Deseja realmente voltar para o painel de administrador?')) {
      fetch("scripts/voltar_admin.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({}),
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          alert("Retornando ao painel de administrador");
          window.location.href = "dashboard.php";
        } else {
          alert(data.message || "Erro ao voltar para o painel de administrador");
        }
      })
      .catch(error => {
        console.error("Erro:", error);
        alert("Erro de conexão");
      });
    }
  }
}
</script>


  <div class="flex flex-col flex-1">
    <main class="p-6 flex-1 overflow-y-auto">

      <!-- Título Gerenciar Logins Expirados no topo -->
      <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4 animate-fadeInUp">
        <div>
          <h2 class="text-lg font-semibold flex items-center gap-2">
            <i class="fas fa-clock text-red-400"></i>
            Gerenciar Logins Expirados
          </h2>
          <p class="text-sm text-slate-400 mt-1">Gerencie usuários com logins expirados</p>
        </div>
      </div>

      <!-- Estatísticas dos logins -->
      <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6 stagger-children">
        
                
        <div class="bg-[#1e293b] p-4 rounded-xl border border-slate-700/50 card-hover animate-fadeInUp" style="--stagger-delay: 3">
          <div class="flex items-center gap-3">
            <div class="bg-orange-500/20 p-3 rounded-full">
              <i class="fas fa-user-clock text-orange-400 text-xl"></i>
            </div>
            <div>
              <p class="text-sm text-slate-400">Meus Expirados</p>
              <p class="text-xl font-bold text-orange-400" id="meusLoginsExpiradosStat">2</p>
            </div>
          </div>
        </div>
        
        <div class="bg-[#1e293b] p-4 rounded-xl border border-slate-700/50 card-hover animate-fadeInUp" style="--stagger-delay: 4">
          <div class="flex items-center gap-3">
            <div class="bg-blue-500/20 p-3 rounded-full">
              <i class="fas fa-list text-blue-400 text-xl"></i>
            </div>
            <div>
              <p class="text-sm text-slate-400">Exibindo</p>
              <p class="text-xl font-bold text-blue-400" id="exibindoStat">2</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Botões de Ação - APENAS PARA LOGINS EXPIRADOS -->
      <div class="bg-[#1e293b] rounded-xl border border-slate-700/50 p-4 mb-6 animate-fadeInUp delay-200">
        <h3 class="text-lg font-semibold mb-4 flex items-center gap-2">
          <i class="fas fa-cogs text-slate-400"></i>
          Ações para Logins
        </h3>
        
        <div class="grid grid-cols-1 md:grid-cols-5 gap-4">
          
          <!-- Adicionar Dias (Apenas Admin) -->
                    
          <!-- Pausar Todos os Logins Ativos (Apenas Admin) -->
                    
          <!-- Resetar Todos os Usuários (Apenas Admin) -->
         <button onclick="confirmResetAllHwids()" 
        class="bg-gradient-to-r from-yellow-400 to-yellow-600 hover:from-yellow-500 hover:to-yellow-700 text-white px-4 py-3 rounded-lg font-semibold transition-all duration-200 hover:scale-105 shadow-lg flex items-center justify-center gap-2">
  <i class="fas fa-sync-alt"></i>
  <span class="text-sm">Resetar Todos os Usuários</span>
</button>

          
          <!-- Deletar Todos os Logins Expirados (Apenas Admin) -->
                    
          <!-- Deletar Meus Logins Expirados -->
          <button onclick="deletarMeusLoginsExpirados()" 
                  class="bg-gradient-to-r from-orange-600 to-orange-700 hover:from-orange-700 hover:to-orange-800 text-white px-4 py-3 rounded-lg font-semibold transition-all duration-200 hover:scale-105 shadow-lg flex items-center justify-center gap-2">
            <i class="fas fa-user-clock"></i>
            <span class="text-sm">Deletar Meus Logins Expirados</span>
          </button>
          
        </div>
      </div>

      <!-- Tabela de Vendedores com Logins Expirados (Apenas Admin) COM PAGINAÇÃO -->
      
      <!-- Filtros para Usuários Expirados -->
      <div class="bg-[#1e293b] rounded-xl border border-slate-700/50 p-4 mb-6 animate-fadeInUp delay-200">
        <form id="filterForm" onsubmit="event.preventDefault(); fetchUsuarios();">
          <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <!-- Campo de busca -->
            <div>
              <label class="block text-sm font-medium text-slate-300 mb-2">
                <i class="fas fa-search mr-2"></i>Buscar usuário
              </label>
              <input type="text" name="search" id="searchInput" value="" placeholder="Digite o nome do usuário..." 
                class="w-full px-4 py-2 rounded-lg bg-slate-800 text-white border border-slate-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all duration-200">
            </div>
            
            <!-- Filtro de vendedor (apenas admin) -->
                        
            <!-- Itens por página -->
            <div>
              <label class="block text-sm font-medium text-slate-300 mb-2">
                <i class="fas fa-list-ol mr-2"></i>Por página
              </label>
              <select name="limit" id="limitSelect" class="w-full px-4 py-2 rounded-lg bg-slate-800 text-white border border-slate-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all duration-200">
                <option value="10" selected>10</option>
                <option value="25" >25</option>
                <option value="50" >50</option>
                <option value="100" >100</option>
              </select>
            </div>
          </div>
        </form>
      </div>

      <!-- Tabela de usuários com logins expirados -->
      <div class="bg-[#1e293b] rounded-xl border border-slate-700/50 overflow-hidden animate-fadeInUp delay-300">
        
        <div class="overflow-x-auto" id="tableContainer">
          <!-- Conteúdo da tabela e paginação será carregado aqui -->
        </div>

      </div>

    </main>
  </div>
</div>

<!-- Incluir modais de alerta -->
<!-- Modais de Alerta para Ações de Usuário -->

<!-- Modal de Confirmação -->
<div id="modalConfirmacao" class="hidden fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-[70]">
  <div class="bg-gradient-to-br from-slate-800 to-slate-900 p-8 rounded-2xl w-full max-w-md relative text-white shadow-2xl transform transition-all duration-500 scale-95 opacity-0 border border-slate-600/50" id="modalConfirmacaoContent">
    
    <div class="text-center space-y-6">
      <!-- Ícone de pergunta -->
      <div class="flex justify-center">
        <div class="w-20 h-20 bg-yellow-500/20 rounded-full flex items-center justify-center relative">
          <div class="w-16 h-16 bg-yellow-500/30 rounded-full flex items-center justify-center animate-pulse">
            <i class="fas fa-question text-yellow-400 text-3xl"></i>
          </div>
          <div class="absolute inset-0 rounded-full border-2 border-yellow-400/50 animate-ping"></div>
        </div>
      </div>
      
      <!-- Título e mensagem -->
      <div>
        <h2 id="confirmacaoTitulo" class="text-xl font-bold text-white mb-3">
          Confirmar Ação
        </h2>
        <p id="confirmacaoMensagem" class="text-slate-300 text-sm leading-relaxed">
          Tem certeza que deseja realizar esta ação?
        </p>
      </div>
      
      <!-- Botões -->
      <div class="flex gap-3 justify-center">
        <button onclick="window.fecharModalConfirmacao(false)" class="bg-slate-600 hover:bg-slate-700 text-white px-6 py-3 rounded-lg font-semibold transition-all duration-200 hover:scale-105 flex items-center gap-2">
          <i class="fas fa-times"></i> Cancelar
        </button>
        <button id="btnConfirmar" onclick="window.confirmarAcao()" class="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-lg font-semibold transition-all duration-200 hover:scale-105 flex items-center gap-2">
          <i class="fas fa-check"></i> Confirmar
        </button>
      </div>
    </div>
  </div>
</div>

<!-- Modal de Sucesso -->
<div id="modalSucesso" class="hidden fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-[70]">
  <div class="bg-gradient-to-br from-green-900 to-green-800 p-8 rounded-2xl w-full max-w-md relative text-white shadow-2xl transform transition-all duration-500 scale-95 opacity-0 border border-green-500/30" id="modalSucessoContent">
    
    <!-- Animação de confete -->
    <div class="absolute inset-0 overflow-hidden rounded-2xl">
      <div class="confetti-container">
        <div class="confetti confetti-1"></div>
        <div class="confetti confetti-2"></div>
        <div class="confetti confetti-3"></div>
      </div>
    </div>
    
    <div class="relative z-10 text-center space-y-6">
      <!-- Ícone de sucesso -->
      <div class="flex justify-center">
        <div class="w-20 h-20 bg-green-500/30 rounded-full flex items-center justify-center relative">
          <div class="w-16 h-16 bg-green-500/50 rounded-full flex items-center justify-center animate-pulse">
            <i class="fas fa-check text-white text-3xl animate-bounce"></i>
          </div>
          <div class="absolute inset-0 rounded-full border-2 border-green-400 animate-ping"></div>
        </div>
      </div>
      
      <!-- Título e mensagem -->
      <div>
        <h2 class="text-2xl font-bold text-green-100 mb-3">
          ✅ Sucesso!
        </h2>
        <p id="sucessoMensagem" class="text-green-200 text-sm leading-relaxed">
          Ação realizada com sucesso!
        </p>
      </div>
      
      <!-- Botão -->
      <button onclick="window.fecharModalSucesso(true)" class="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-semibold transition-all duration-200 hover:scale-105 flex items-center justify-center gap-2 mx-auto">
        <i class="fas fa-check-circle"></i> Continuar
      </button>
    </div>
  </div>
</div>

<!-- Modal de Erro -->
<div id="modalErro" class="hidden fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-[70]">
  <div class="bg-gradient-to-br from-red-900 to-red-800 p-8 rounded-2xl w-full max-w-md relative text-white shadow-2xl transform transition-all duration-500 scale-95 opacity-0 border border-red-500/30" id="modalErroContent">
    
    <div class="text-center space-y-6">
      <!-- Ícone de erro -->
      <div class="flex justify-center">
        <div class="w-20 h-20 bg-red-500/30 rounded-full flex items-center justify-center relative">
          <div class="w-16 h-16 bg-red-500/50 rounded-full flex items-center justify-center animate-pulse">
            <i class="fas fa-exclamation-triangle text-white text-3xl animate-bounce"></i>
          </div>
          <div class="absolute inset-0 rounded-full border-2 border-red-400 animate-ping"></div>
        </div>
      </div>
      
      <!-- Título e mensagem -->
      <div>
        <h2 class="text-2xl font-bold text-red-100 mb-3">
          ❌ Erro!
        </h2>
        <p id="erroMensagem" class="text-red-200 text-sm leading-relaxed">
          Ocorreu um erro ao realizar a ação.
        </p>
      </div>
      
      <!-- Botão -->
      <button onclick="window.fecharModalErro(true)" class="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-lg font-semibold transition-all duration-200 hover:scale-105 flex items-center justify-center gap-2 mx-auto">
        <i class="fas fa-times-circle"></i> Fechar
      </button>
    </div>
  </div>
</div>

<!-- Modal de Aviso -->
<div id="modalAviso" class="hidden fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-[70]">
  <div class="bg-gradient-to-br from-orange-900 to-orange-800 p-8 rounded-2xl w-full max-w-md relative text-white shadow-2xl transform transition-all duration-500 scale-95 opacity-0 border border-orange-500/30" id="modalAvisoContent">
    
    <div class="text-center space-y-6">
      <!-- Ícone de aviso -->
      <div class="flex justify-center">
        <div class="w-20 h-20 bg-orange-500/30 rounded-full flex items-center justify-center relative">
          <div class="w-16 h-16 bg-orange-500/50 rounded-full flex items-center justify-center animate-pulse">
            <i class="fas fa-exclamation text-white text-3xl animate-bounce"></i>
          </div>
          <div class="absolute inset-0 rounded-full border-2 border-orange-400 animate-ping"></div>
        </div>
      </div>
      
      <!-- Título e mensagem -->
      <div>
        <h2 class="text-2xl font-bold text-orange-100 mb-3">
          ⚠️ Atenção!
        </h2>
        <p id="avisoMensagem" class="text-orange-200 text-sm leading-relaxed">
          Informação importante.
        </p>
      </div>
      
      <!-- Botão -->
      <button onclick="window.fecharModalAviso(true)" class="bg-orange-600 hover:bg-orange-700 text-white px-6 py-3 rounded-lg font-semibold transition-all duration-200 hover:scale-105 flex items-center justify-center gap-2 mx-auto">
        <i class="fas fa-info-circle"></i> Entendi
      </button>
    </div>
  </div>
</div>

<style>
/* Animações para os modais de alerta */
.confetti-container {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
}

.confetti {
  position: absolute;
  width: 6px;
  height: 6px;
  animation: confetti-fall 2s linear infinite;
}

.confetti-1 { 
  left: 20%; 
  animation-delay: 0s; 
  background: #ffd700; 
  border-radius: 50%;
}
.confetti-2 { 
  left: 50%; 
  animation-delay: 0.5s; 
  background: #4ade80; 
  border-radius: 2px;
}
.confetti-3 { 
  left: 80%; 
  animation-delay: 1s; 
  background: #60a5fa; 
  border-radius: 50%;
}

@keyframes confetti-fall {
  0% {
    transform: translateY(-50px) rotate(0deg);
    opacity: 1;
  }
  100% {
    transform: translateY(300px) rotate(360deg);
    opacity: 0;
  }
}

/* Animações de entrada dos modais */
.modal-show {
  opacity: 1 !important;
  transform: scale(1) !important;
}

/* Efeito de shake para erros */
@keyframes shake {
  0%, 100% { transform: translateX(0); }
  10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
  20%, 40%, 60%, 80% { transform: translateX(5px); }
}

.shake {
  animation: shake 0.5s ease-in-out;
}
</style>

<script>
// Variáveis globais para controle dos modais
let acaoConfirmada = null;
let parametrosAcao = null;
let recarregarPaginaAposAcao = false; // Nova variável para controlar o recarregamento

// Função para mostrar modal de confirmação
window.mostrarConfirmacao = function(titulo, mensagem, callback, params = null, tipoBtn = 'danger', recarregar = false) {
  document.getElementById('confirmacaoTitulo').textContent = titulo;
  document.getElementById('confirmacaoMensagem').textContent = mensagem;
  
  // Configurar botão baseado no tipo
  const btnConfirmar = document.getElementById('btnConfirmar');
  if (tipoBtn === 'danger') {
    btnConfirmar.className = 'bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-lg font-semibold transition-all duration-200 hover:scale-105 flex items-center gap-2';
    btnConfirmar.innerHTML = '<i class="fas fa-check"></i> Confirmar';
  } else if (tipoBtn === 'warning') {
    btnConfirmar.className = 'bg-orange-600 hover:bg-orange-700 text-white px-6 py-3 rounded-lg font-semibold transition-all duration-200 hover:scale-105 flex items-center gap-2';
    btnConfirmar.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Prosseguir';
  } else {
    btnConfirmar.className = 'bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold transition-all duration-200 hover:scale-105 flex items-center gap-2';
    btnConfirmar.innerHTML = '<i class="fas fa-check"></i> Confirmar';
  }
  
  acaoConfirmada = callback;
  parametrosAcao = params;
  recarregarPaginaAposAcao = recarregar; // Define se a página deve recarregar
  
  const modal = document.getElementById('modalConfirmacao');
  const content = document.getElementById('modalConfirmacaoContent');
  
  modal.classList.remove('hidden');
  
  setTimeout(() => {
    content.classList.remove('scale-95', 'opacity-0');
    content.classList.add('scale-100', 'opacity-100');
  }, 10);
};

// Função para confirmar ação
window.confirmarAcao = function() {
  if (acaoConfirmada) {
    if (parametrosAcao) {
      acaoConfirmada(...parametrosAcao);
    } else {
      acaoConfirmada();
    }
  }
  window.fecharModalConfirmacao(true); // Fechar o modal de confirmação após a ação
};

// Função para fechar modal de confirmação
window.fecharModalConfirmacao = function(confirmado = false) {
  const modal = document.getElementById('modalConfirmacao');
  const content = document.getElementById('modalConfirmacaoContent');
  
  content.classList.add('scale-95', 'opacity-0');
  content.classList.remove('scale-100', 'opacity-100');
  
  setTimeout(() => {
    modal.classList.add('hidden');
    if (!confirmado) {
      acaoConfirmada = null;
      parametrosAcao = null;
      recarregarPaginaAposAcao = false; // Resetar a flag
    }
  }, 300);
};

// Função para mostrar modal de sucesso
window.mostrarSucesso = function(mensagem, autoClose = true) {
  document.getElementById('sucessoMensagem').textContent = mensagem;
  
  const modal = document.getElementById('modalSucesso');
  const content = document.getElementById('modalSucessoContent');
  
  modal.classList.remove('hidden');
  
  setTimeout(() => {
    content.classList.remove('scale-95', 'opacity-0');
    content.classList.add('scale-100', 'opacity-100');
  }, 10);
  
  if (autoClose) {
    setTimeout(() => {
      window.fecharModalSucesso(recarregarPaginaAposAcao); // Passa a flag de recarregamento
    }, 3000);
  }
};

// Função para fechar modal de sucesso
window.fecharModalSucesso = function(recarregar = false) {
  const modal = document.getElementById('modalSucesso');
  const content = document.getElementById('modalSucessoContent');
  
  content.classList.add('scale-95', 'opacity-0');
  content.classList.remove('scale-100', 'opacity-100');
  
  setTimeout(() => {
    modal.classList.add('hidden');
    if (recarregar) {
      location.reload(); // Recarrega a página se a flag for verdadeira
    }
  }, 300);
};

// Função para mostrar modal de erro
window.mostrarErro = function(mensagem, autoClose = false) {
  document.getElementById('erroMensagem').textContent = mensagem;
  
  const modal = document.getElementById('modalErro');
  const content = document.getElementById('modalErroContent');
  
  modal.classList.remove('hidden');
  
  setTimeout(() => {
    content.classList.remove('scale-95', 'opacity-0');
    content.classList.add('scale-100', 'opacity-100');
    content.classList.add('shake');
    
    setTimeout(() => {
      content.classList.remove('shake');
    }, 500);
  }, 10);
  
  if (autoClose) {
    setTimeout(() => {
      window.fecharModalErro(); // Não recarrega a página
    }, 4000);
  }
};

// Função para fechar modal de erro
window.fecharModalErro = function() {
  const modal = document.getElementById('modalErro');
  const content = document.getElementById('modalErroContent');
  
  content.classList.add('scale-95', 'opacity-0');
  content.classList.remove('scale-100', 'opacity-100');
  
  setTimeout(() => {
    modal.classList.add('hidden');
    if (recarregar) {
      location.reload(); // Recarrega a página se a flag for verdadeira
    }
  }, 300);
};

// Função para mostrar modal de aviso
window.mostrarAviso = function(mensagem, autoClose = false) {
  document.getElementById('avisoMensagem').textContent = mensagem;
  
  const modal = document.getElementById('modalAviso');
  const content = document.getElementById('modalAvisoContent');
  
  modal.classList.remove('hidden');
  
  setTimeout(() => {
    content.classList.remove('scale-95', 'opacity-0');
    content.classList.add('scale-100', 'opacity-100');
  }, 10);
  
  if (autoClose) {
    setTimeout(() => {
      window.fecharModalAviso(recarregarPaginaAposAcao); // Passa a flag de recarregamento
    }, 3000);
  }
};

// Função para fechar modal de aviso
window.fecharModalAviso = function(recarregar = false) {
  const modal = document.getElementById('modalAviso');
  const content = document.getElementById('modalAvisoContent');
  
  content.classList.add('scale-95', 'opacity-0');
  content.classList.remove('scale-100', 'opacity-100');
  
  setTimeout(() => {
    modal.classList.add('hidden');
    if (recarregar) {
      location.reload(); // Recarrega a página se a flag for verdadeira
    }
  }, 300);
};

// Event listeners para fechar modais clicando fora
document.addEventListener('click', function(e) {
  if (e.target.id === 'modalConfirmacao') {
    window.fecharModalConfirmacao(false);
  } else if (e.target.id === 'modalSucesso') {
    window.fecharModalSucesso();
  } else if (e.target.id === 'modalErro') {
    window.fecharModalErro();
  } else if (e.target.id === 'modalAviso') {
    window.fecharModalAviso();
  }
});

// Event listener para ESC
document.addEventListener('keydown', function(e) {
  if (e.key === 'Escape') {
    window.fecharModalConfirmacao(false);
    window.fecharModalSucesso();
    window.fecharModalErro();
    window.fecharModalAviso();
  }
});

</script>



<script>
// Função para deletar todos os logins expirados (apenas admin)
function deletarLoginsExpirados() {
    console.log('Iniciando deletarLoginsExpirados');
    window.mostrarConfirmacao(
        '⚠️ DELETAR LOGINS EXPIRADOS',
        'Tem certeza que deseja remover TODOS os logins expirados do sistema?\n\nEsta ação afetará usuários de todos os vendedores.',
        () => {
            console.log('Confirmação de deletarLoginsExpirados aceita. Executando ação...');
            executarAcao('deletar_logins_expirados');
        },
        null,
        'warning'
    );
}

// Função para deletar meus logins expirados
function deletarMeusLoginsExpirados() {
    console.log('Iniciando deletarMeusLoginsExpirados');
    window.mostrarConfirmacao(
        '⚠️ DELETAR MEUS LOGINS EXPIRADOS',
        'Tem certeza que deseja remover os logins expirados dos seus usuários?',
        () => {
            console.log('Confirmação de deletarMeusLoginsExpirados aceita. Executando ação...');
            executarAcao('deletar_meus_logins_expirados');
        },
        null,
        'warning'
    );
}

// Função para deletar logins expirados de um seller específico (apenas admin)
function deletarLoginsExpiradosSeller(seller) {
    console.log('Iniciando deletarLoginsExpiradosSeller para o vendedor:', seller);
    window.mostrarConfirmacao(
        '⚠️ DELETAR LOGINS EXPIRADOS DO VENDEDOR',
        `Tem certeza que deseja remover os logins expirados dos usuários do vendedor "${seller}"?`,
        () => {
            console.log('Confirmação de deletarLoginsExpiradosSeller aceita. Executando ação...');
            executarAcao('deletar_logins_expirados_seller', { seller: seller });
        },
        null,
        'warning'
    );
}

// Função para executar as ações
function executarAcao(acao, params = {}) {
    console.log('executarAcao chamada com:', acao, params);
    const formData = new FormData();
    formData.append('acao', acao);
    
    // Adicionar parâmetros extras se houver
    for (const [key, value] of Object.entries(params)) {
        formData.append(key, value);
    }
    
    fetch('scripts/delete_logins.php', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        console.log('Resposta do fetch recebida:', response);
        return response.json();
    })
    .then(data => {
        console.log('Dados da resposta JSON:', data);
        if (data.success) {
            window.mostrarSucesso(data.message);
            setTimeout(() => {
                location.reload();
            }, 2000);
        } else {
            window.mostrarErro(data.message || 'Erro ao executar ação');
        }
    })
    .catch(error => {
        console.error('Erro na requisição fetch:', error);
        window.mostrarErro('Erro de conexão');
    });
}

// Função para buscar usuários com filtros e página
function fetchUsuarios(page = 1) {
    const formData = new FormData(document.getElementById('filterForm'));
    const params = new URLSearchParams();
    
    for (let [key, value] of formData.entries()) {
        if (value.trim() !== '') {
            params.append(key, value);
        }
    }
    
    params.append('page', page); // Adicionar página atual
    params.append('ajax_type', 'usuarios'); // Identificar tipo de AJAX
    
    // Fazer requisição AJAX
    fetch('?' + params.toString(), {
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        // Atualizar tabela
        document.getElementById('tableContainer').innerHTML = data.table;
        
        // Atualizar estatísticas
        document.getElementById('exibindoStat').textContent = data.totalUsuariosExpirados.toLocaleString();
        
        // Atualizar URL sem recarregar a página
        const newUrl = window.location.pathname + '?' + params.toString().replace('ajax_type=usuarios&', '');
        window.history.pushState({}, '', newUrl);
    })
    .catch(error => {
        console.error('Erro ao buscar usuários:', error);
        window.mostrarErro('Erro ao carregar dados');
    });
}

// Função para buscar vendedores com filtros e página
function fetchVendedores(page = 1) {
    const formData = new FormData(document.getElementById('vendedorFilterForm'));
    const params = new URLSearchParams();
    
    for (let [key, value] of formData.entries()) {
        if (value.trim() !== '') {
            params.append(key, value);
        }
    }
    
    params.append('vendedor_page', page); // Adicionar página atual
    params.append('ajax_type', 'vendedores'); // Identificar tipo de AJAX
    
    // Fazer requisição AJAX
    fetch('?' + params.toString(), {
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        // Atualizar tabela de vendedores
        document.getElementById('vendedorTableContainer').innerHTML = data.table;
    })
    .catch(error => {
        console.error('Erro ao buscar vendedores:', error);
        window.mostrarErro('Erro ao carregar dados de vendedores');
    });
}

// Event listeners para filtros
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchInput');
    const vendedorSelect = document.getElementById('vendedorSelect');
    const limitSelect = document.getElementById('limitSelect');
    const mainContentArea = document.querySelector('main'); // Área principal que contém as tabelas
    
    // Filtros para vendedores
    const vendedorSearchInput = document.getElementById('vendedorSearchInput');
    const vendedorLimitSelect = document.getElementById('vendedorLimitSelect');
    
    // Busca em tempo real para usuários
    let searchTimeout;
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => fetchUsuarios(1), 500); // Reset para página 1 ao filtrar
        });
    }
    
    // Filtros instantâneos para usuários
    if (vendedorSelect) {
        vendedorSelect.addEventListener('change', () => fetchUsuarios(1)); // Reset para página 1 ao filtrar
    }
    
    if (limitSelect) {
        limitSelect.addEventListener('change', () => fetchUsuarios(1)); // Reset para página 1 ao filtrar
    }

    // Busca em tempo real para vendedores
    let vendedorSearchTimeout;
    if (vendedorSearchInput) {
        vendedorSearchInput.addEventListener('input', function() {
            clearTimeout(vendedorSearchTimeout);
            vendedorSearchTimeout = setTimeout(() => fetchVendedores(1), 500); // Reset para página 1 ao filtrar
        });
    }
    
    // Filtros instantâneos para vendedores
    if (vendedorLimitSelect) {
        vendedorLimitSelect.addEventListener('change', () => fetchVendedores(1)); // Reset para página 1 ao filtrar
    }

    // Delegação de eventos para os botões de paginação (usuários e vendedores)
    if (mainContentArea) {
        mainContentArea.addEventListener('click', function(event) {
            if (event.target.closest('.pagination-button')) {
                const page = parseInt(event.target.closest('.pagination-button').dataset.page);
                if (!isNaN(page)) {
                    fetchUsuarios(page);
                }
            }
            
            if (event.target.closest('.vendedor-pagination-button')) {
                const page = parseInt(event.target.closest('.vendedor-pagination-button').dataset.page);
                if (!isNaN(page)) {
                    fetchVendedores(page);
                }
            }
        });
    }

    // Carregar as tabelas iniciais ao carregar a página
    fetchUsuarios(1);
    });

// Função para despausar todos os logins
function despausarTodosLogins() {
    mostrarConfirmacao(
        'Despausar Todos os Logins',
        'Tem certeza que deseja despausar TODOS os logins pausados? Os dias correspondentes serão devolvidos automaticamente.',
        () => {
            executarDespauseTodosLogins();
        },
        null,
        'warning'
    );
}

function confirmResetAllHwids() {
    mostrarConfirmacao(
        'Resetar Todos os Usuários',
        'Tem certeza que deseja Resetar Todos os Usuários?',
        () => {
            executarResetAllhwid();
        },
        null,
        'warning'
    );
}

async function executarResetAllhwid() {
    try {
        const formData = new FormData();
        formData.append('acao', 'resetar_todos_hwid');
        
        const response = await fetch('scripts/resetar_todos.php', {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const result = await response.json();
        
        if (result.success) {
            mostrarSucesso(result.message);
            setTimeout(() => {
                if (typeof fetchUsuarios === 'function') {
                    fetchUsuarios();
                } else {
                    location.reload();
                }
            }, 1500);
        } else {
            mostrarErro(result.message || 'Erro ao despausar logins');
        }
    } catch (error) {
        console.error('Erro na requisição:', error);
        mostrarErro('Erro de conexão: ' + error.message);
    }
}

async function executarDespauseTodosLogins() {
    try {
        const formData = new FormData();
        formData.append('acao', 'despausar_todos_logins');
        
        const response = await fetch('scripts/admin_actions.php', {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const result = await response.json();
        
        if (result.success) {
            mostrarSucesso(result.message);
            setTimeout(() => {
                if (typeof fetchUsuarios === 'function') {
                    fetchUsuarios();
                } else {
                    location.reload();
                }
            }, 1500);
        } else {
            mostrarErro(result.message || 'Erro ao despausar logins');
        }
    } catch (error) {
        console.error('Erro na requisição:', error);
        mostrarErro('Erro de conexão: ' + error.message);
    }
}
</script>

<!-- Modal Pausar Todos os Logins -->
<!-- Modal Pausar Todos os Logins -->
<div id="modalPausarTodosLogins" class="hidden fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50">
  <div class="bg-[#1e293b] p-6 rounded-lg w-full max-w-md relative text-white shadow-2xl transform transition-all duration-300 scale-95 opacity-0" id="modalPausarTodosLoginsContent">
    <h2 class="text-xl font-bold mb-4 flex items-center gap-2">
      <i class="fas fa-pause-circle text-red-400"></i> Pausar Todos os Logins Ativos
    </h2>

    <p class="text-sm text-slate-300 mb-4">
      Esta ação irá pausar todos os logins que estão atualmente ativos (is_active = 1 e pausado_em = NULL).
      Você pode escolher pausar imediatamente ou agendar para uma data e hora futuras ou passadas.
    </p>

    <form id="formPausarTodosLogins">
      <input type="hidden" name="acao" value="pausar_todos_logins">

      <div class="mb-4">
        <label class="block text-sm font-medium text-slate-300 mb-2">
          <i class="fas fa-calendar-alt mr-2"></i>Agendar Pausa:
        </label>
        <div class="flex items-center gap-2">
          <input type="datetime-local" name="data_pausa" id="inputDataPausa" class="w-full px-3 py-2 rounded-lg bg-[#0f172a] text-white border border-slate-600 focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all duration-200">
        </div>
        <p class="text-xs text-slate-400 mt-1">Deixe em branco para pausar imediatamente.</p>
      </div>

      <div class="flex justify-between gap-3">
        <button type="submit" id="btnConfirmarPausa" class="flex-1 bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg transition-all duration-200 flex items-center justify-center gap-2">
          <i class="fas fa-pause"></i>
          Confirmar Pausa
        </button>
        <button type="button" onclick="closeModal('modalPausarTodosLogins')" class="flex-1 bg-slate-600 hover:bg-slate-700 text-white px-4 py-2 rounded-lg transition-all duration-200">
          Cancelar
        </button>
      </div>
    </form>

    <button onclick="closeModal('modalPausarTodosLogins')" class="absolute top-2 right-3 text-slate-400 hover:text-red-400 text-xl transition-colors duration-200">&times;</button>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const formPausarTodosLogins = document.getElementById('formPausarTodosLogins');
  if (formPausarTodosLogins) {
    formPausarTodosLogins.addEventListener('submit', async function(e) {
      e.preventDefault();
      
      const dataPausa = document.getElementById('inputDataPausa').value;
      let mensagemConfirmacao = 'Tem certeza que deseja pausar TODOS os logins ativos imediatamente?';
      if (dataPausa) {
        mensagemConfirmacao = `Tem certeza que deseja agendar a pausa de TODOS os logins ativos para ${new Date(dataPausa).toLocaleString()}?`;
      }

      mostrarConfirmacao(
        'Pausar Todos os Logins',
        mensagemConfirmacao,
        () => {
          executarPausaTodosLogins(new FormData(formPausarTodosLogins));
        },
        null,
        'warning'
      );
    });
  }
});

async function executarPausaTodosLogins(formData) {
  try {
    const response = await fetch('scripts/admin_actions.php', {
      method: 'POST',
      body: formData
    });
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const result = await response.json();
    
    if (result.success) {
      mostrarSucesso(result.message);
      closeModal('modalPausarTodosLogins');
      setTimeout(() => {
        if (typeof fetchUsers === 'function') {
          fetchUsers();
        } else {
          location.reload();
        }
      }, 1500);
    } else {
      mostrarErro(result.message || 'Erro ao pausar logins');
    }
  } catch (error) {
    console.error('Erro na requisição:', error);
    mostrarErro('Erro de conexão: ' + error.message);
  }
}
</script>


<!-- Modal Adicionar Dias Gerenciar -->
<!-- Modal Adicionar Dias - Gerenciar Logins -->
<div id="modalAdicionarDiasGerenciar" class="hidden fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50">
  <div class="bg-gradient-to-br from-slate-800 to-slate-900 p-8 rounded-2xl w-full max-w-md relative text-white shadow-2xl transform transition-all duration-500 scale-95 opacity-0 border border-slate-600/50" id="modalAdicionarDiasGerenciarContent">
    
    <!-- Botão fechar -->
    <button onclick="window.closeModal('modalAdicionarDiasGerenciar')" class="absolute top-4 right-4 text-slate-400 hover:text-white transition-colors">
      <i class="fas fa-times text-xl"></i>
    </button>
    
    <div class="space-y-6">
      <!-- Cabeçalho -->
      <div class="text-center">
        <div class="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
          <i class="fas fa-calendar-plus text-green-400 text-2xl"></i>
        </div>
        <h2 class="text-2xl font-bold text-white mb-2">Adicionar Dias</h2>
        <p class="text-slate-400 text-sm">Adicione dias aos logins ativos</p>
      </div>
      
      <!-- Formulário -->
      <form id="formAdicionarDiasGerenciar" onsubmit="submitAdicionarDiasGerenciar(event)">
        <div class="space-y-4">
          
          <!-- Tipo de Ação -->
          <div>
            <label class="block text-sm font-medium text-slate-300 mb-2">
              <i class="fas fa-cogs mr-2"></i>Tipo de Ação
            </label>
            <select id="tipoAcaoGerenciar" name="tipo_acao" required onchange="toggleProdutoSelectGerenciar()"
                    class="w-full px-4 py-3 rounded-lg bg-slate-700 text-white border border-slate-600 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200">
              <option value="">Selecione uma opção</option>
              <option value="todos">Adicionar a todos os logins ativos</option>
              <option value="produto">Adicionar por produto específico</option>
            </select>
          </div>
          
          <!-- Produto e Versão (aparece apenas quando selecionado "produto") -->
          <div id="divProdutoGerenciar" class="hidden">
            <label class="block text-sm font-medium text-slate-300 mb-2">
              <i class="fas fa-cube mr-2"></i>Produto e Versão
            </label>
            <select id="produtoVersaoGerenciar" name="produto_versao" 
                    class="w-full px-4 py-3 rounded-lg bg-slate-700 text-white border border-slate-600 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200">
              <option value="">Selecione um produto</option>
                              <option value="ApkMod Brutal 1.0">ApkMod Brutal 1.0</option>
                          </select>
          </div>
          
          <!-- Quantidade de Dias -->
          <div>
            <label class="block text-sm font-medium text-slate-300 mb-2">
              <i class="fas fa-calendar-days mr-2"></i>Quantidade de Dias
            </label>
            <input type="number" id="quantidadeDiasGerenciar" name="quantidade_dias" min="1" required 
                   class="w-full px-4 py-3 rounded-lg bg-slate-700 text-white border border-slate-600 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200"
                   placeholder="Ex: 30">
          </div>
          
          <!-- Informação sobre critérios -->
          <div class="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4">
            <div class="flex items-start gap-3">
              <i class="fas fa-info-circle text-blue-400 mt-1"></i>
              <div class="text-sm text-blue-300">
                <p class="font-semibold mb-1">Critérios para adicionar dias:</p>
                <ul class="text-xs text-blue-200 space-y-1">
                  <li>• Apenas logins ativos (is_active = 1)</li>
                  <li>• Apenas logins não pausados (pausado_em = null)</li>
                  <li>• Os dias serão adicionados à data de expiração atual</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        
        <!-- Botões -->
        <div class="flex gap-3 mt-8">
          <button type="button" onclick="window.closeModal('modalAdicionarDiasGerenciar')" 
                  class="flex-1 bg-slate-600 hover:bg-slate-700 text-white px-6 py-3 rounded-lg font-semibold transition-all duration-200 hover:scale-105 flex items-center justify-center gap-2">
            <i class="fas fa-times"></i> Cancelar
          </button>
          <button type="submit" 
                  class="flex-1 bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white px-6 py-3 rounded-lg font-semibold transition-all duration-200 hover:scale-105 flex items-center justify-center gap-2">
            <i class="fas fa-calendar-plus"></i> Adicionar Dias
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
// Função para mostrar/ocultar select de produto
function toggleProdutoSelectGerenciar() {
  const tipoAcao = document.getElementById('tipoAcaoGerenciar').value;
  const divProduto = document.getElementById('divProdutoGerenciar');
  const selectProduto = document.getElementById('produtoVersaoGerenciar');
  
  if (tipoAcao === 'produto') {
    divProduto.classList.remove('hidden');
    selectProduto.required = true;
  } else {
    divProduto.classList.add('hidden');
    selectProduto.required = false;
    selectProduto.value = '';
  }
}

// Função para submeter o formulário
function submitAdicionarDiasGerenciar(event) {
  event.preventDefault();
  
  const tipoAcao = document.getElementById('tipoAcaoGerenciar').value;
  const produtoVersao = document.getElementById('produtoVersaoGerenciar').value;
  const quantidadeDias = document.getElementById('quantidadeDiasGerenciar').value;
  
  // Validações
  if (!tipoAcao) {
    window.mostrarErro('Selecione o tipo de ação');
    return;
  }
  
  if (tipoAcao === 'produto' && !produtoVersao) {
    window.mostrarErro('Selecione um produto');
    return;
  }
  
  if (!quantidadeDias || quantidadeDias < 1) {
    window.mostrarErro('Digite uma quantidade válida de dias');
    return;
  }
  
  // Preparar mensagem de confirmação
  let mensagem = '';
  if (tipoAcao === 'todos') {
    mensagem = `Tem certeza que deseja adicionar ${quantidadeDias} dias a TODOS os logins ativos?`;
  } else {
    mensagem = `Tem certeza que deseja adicionar ${quantidadeDias} dias a todos os logins ativos do produto "${produtoVersao}"?`;
  }
  
  // Mostrar confirmação
  window.mostrarConfirmacao(
    'Adicionar Dias',
    mensagem,
    () => {
      executarAdicionarDiasGerenciar(tipoAcao, produtoVersao, quantidadeDias);
    },
    null,
    'warning'
  );
}

// Função para executar a adição de dias
async function executarAdicionarDiasGerenciar(tipoAcao, produtoVersao, quantidadeDias) {
  try {
    const formData = new FormData();
    formData.append('acao', 'adicionar_dias_gerenciar');
    formData.append('tipo_acao', tipoAcao);
    formData.append('produto_versao', produtoVersao);
    formData.append('quantidade_dias', quantidadeDias);
    
    // Mostrar loading no botão
    const submitBtn = document.querySelector('#formAdicionarDiasGerenciar button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processando...';
    submitBtn.disabled = true;
    
    const response = await fetch('scripts/admin_actions.php', {
      method: 'POST',
      body: formData
    });
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const result = await response.json();
    
    if (result.success) {
      window.mostrarSucesso(result.message);
      window.closeModal('modalAdicionarDiasGerenciar');
      
      // Limpar formulário
      document.getElementById('formAdicionarDiasGerenciar').reset();
      toggleProdutoSelectGerenciar();
      
      // Atualizar página após 1.5 segundos
      setTimeout(() => {
        location.reload();
      }, 1500);
    } else {
      window.mostrarErro(result.message || 'Erro ao adicionar dias');
    }
  } catch (error) {
    console.error('Erro na requisição:', error);
    window.mostrarErro('Erro de conexão: ' + error.message);
  } finally {
    // Restaurar botão
    const submitBtn = document.querySelector('#formAdicionarDiasGerenciar button[type="submit"]');
    if (submitBtn) {
      submitBtn.innerHTML = '<i class="fas fa-calendar-plus"></i> Adicionar Dias';
      submitBtn.disabled = false;
    }
  }
}
</script>


<script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"version":"2024.11.0","token":"f288f319f18e490b9a89e8a7805b0616","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
</body>
</html>

